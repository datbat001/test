package com.example.customviewimple.model

data class DataModel(val img : Int, val text : String) {
}