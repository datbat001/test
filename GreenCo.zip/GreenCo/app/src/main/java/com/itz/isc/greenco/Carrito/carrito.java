package com.itz.isc.greenco.Carrito;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;
import com.itz.isc.greenco.R;
import com.itz.isc.greenco.adapters.carritoAdapter;

import java.util.ArrayList;
import java.util.List;

public class carrito extends AppCompatActivity implements carritoAdapter.onItemClickListener{

    RecyclerView carritoRecycler;
    List<String> carrito;
    carritoAdapter adapter;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carrito);
        carritoRecycler = findViewById(R.id.idCarritoRecycler);

        carrito = new ArrayList<String>();

        String arr[]
                = {"a","a","a","a","a","a","a",};

        for(int i=0;i==1;i++){

            carrito.set(i, arr[i]);
        }
        extractCarrito();

    }

    private void extractCarrito() {
        RequestQueue queue = Volley.newRequestQueue(this);
        //JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET,JSON)
    }


    @Override
    public void onItemClick(int position) {
        
    }
}