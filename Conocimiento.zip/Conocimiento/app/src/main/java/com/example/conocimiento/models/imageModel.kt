package com.example.conocimiento.models

data class imageModel (val img : Int,val text : String)